
package com.badlogic.gdx.tools.flame;

/** @author Inferno */
public class EmptyPanel extends EditorPanel {

	public EmptyPanel (FlameMain particleEditor3D, String name, String desc) {
		super(particleEditor3D, name, desc);
		setValue(null);
	}
}
